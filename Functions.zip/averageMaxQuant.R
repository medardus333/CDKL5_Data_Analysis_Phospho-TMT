## # # # # # # # # # # # # # # # # # # # # # # # #
##
## Project: CDKL5-NLS Phosphoproteomics
##
## Script name: averageMaxQuant.R
##
## Purpose of script: Average MaxQuant data
##
## averageMaxQuant(data, fractions)
## data is an "evidence.txt" data.frame
## fractions is a vector containing the names of the fractions as they appear in data$Experiment
## 
## Peptides with one observatiton are kept
## Peptides with two observations get averaged
## Peptide with three or more observation: Peptides are averaged or peptide with median ratio WT/KD is taken
## This is being done for each fraction independently to avoid bias by fraction dependent co-isolation populations 
##
## Author: Florian Weiland
##
## Date Created: 2020-04-03
##
## # # # # # # # # # # # # # # # # # # # # # # # #

averageMaxQuant <- function(data, fractions){
  
  data <- data[order(data$Modified.sequence), ]
  
  data.fr.final <- data.frame()
  
  progress.bar.1 <- txtProgressBar(min = 0, max = length(fractions), style = 3)  

  for (cur.frac in fractions) {
    
    setTxtProgressBar(progress.bar.1, cur.frac)
    
    ## Data is averaged within each analysed fraction
    
    fr <- grep(
      paste0("^", cur.frac,"$"),
      data$Experiment
    )
    
    data.fr <- data[fr, ]
    
    ## Count number of observations of each peptide, sort to be able to expand table
    
    data.fr <- data.fr[order(data.fr$Modified.sequence), ]
    
    repeater <- as.vector(table(data.fr$Modified.sequence))
    
    ## Need to expand the table to have same elements as rows in data.fr
    
    times.measured <- rep(repeater, repeater)
    
    data.fr[, "Number.peptide.measured"] <- times.measured
    
    ## Put peptides with one observation into dataframe
    
    one.obs <- which(data.fr$Number.peptide.measured == 1)
    
    data.fr.1 <- data.fr[one.obs, ]
    
    ## Two observations get averaged 
    
    two.obs <- which(data.fr$Number.peptide.measured == 2)
    
    data.fr.2 <- data.fr[two.obs, ]
    
    fr.2.mod.seq <- unique(data.fr.2$Modified.sequence)
    
    for (cur.pep.two in fr.2.mod.seq) {
      
      pep.rows <- which(data.fr.2$Modified.sequence == cur.pep.two)
      
      pep.av <- colMeans(data.fr.2[pep.rows, c(group.wt, group.kd)], na.rm = TRUE)
      
      data.fr.2[pep.rows[1], c(group.wt, group.kd)] <- pep.av
      
    }
    
    ## Averaged value gets put into row of first observation of peptide, need to discard the rest
    
    data.fr.2 <- data.fr.2[seq(1, nrow(data.fr.2), 2), ]
    
    ## Three or more observations get the median taken (this accounts for partial co-isolation over elution window)
    ## => Hint for co-isolation of diff abundant peptide if ratio of WT/KD changes dramatically over all observations
    
    data.fr.3 <- data.fr[-c(one.obs, two.obs), ]
    
    uni.pep <- unique(data.fr.3$Modified.sequence)
    
    for (cur.pep.three in uni.pep) {
      
      temp.rows <- which(data.fr.3[ , "Modified.sequence"] == cur.pep.three)
      
      ratio.temp <- rowMeans(data.fr.3[temp.rows, group.wt], na.rm = TRUE) / 
        rowMeans(data.fr.3[temp.rows, group.kd], na.rm = TRUE)
      
      ## data is log-normal, therefore need adjusted coefficient of variation formula
      
      rem.nan <- as.integer(which(is.nan(ratio.temp) == TRUE))
      
      if (length(rem.nan) != 0) {
        
        ratio.temp <- ratio.temp[-rem.nan]
        
      }
      
      sd.ln <- sd(log(as.vector(ratio.temp)))^2
      
      cv <- sqrt(exp(sd.ln) - 1)
      
      ## If Coefficient of Variation <= 0.1 keep all data rows and take the mean, otherwise take the median
      
      if (cv <= 0.1) {
        
        pep.av <- colMeans(data.fr.3[temp.rows, c(group.wt, group.kd)], na.rm = TRUE)
        
      } else {
        
        med.row <- as.integer(which(ratio.temp == median(ratio.temp)))
        
        pep.av <-  data.fr.3[temp.rows[med.row], c(group.wt, group.kd)]
        
        ## If median is average of two observations, average these two
        ## Needs to be rounded otherwise minuscule differences can occur
        
        if (length(med.row) == 0) {
          
          min.med <- ratio.temp - median(ratio.temp)
          min.med.rows <- which(abs(round(min.med, 9)) == min(abs(round(min.med, 9))))
          
          pep.av <- colMeans(data.fr.3[temp.rows[min.med.rows], c(group.wt, group.kd)], na.rm = TRUE)
        }
      }
      
      data.fr.3[temp.rows[1], c(group.wt, group.kd)] <- pep.av
      
    }
    
    ## Only the first occurence of each sequence contains the average or median (temp.rows[1])
    ## !duplicated extracts first occurence
    
    data.fr.3 <- data.fr.3[!duplicated(data.fr.3$Modified.sequence), ]
    
    ## Combine all data
    
    data.comb <- rbind(
      data.fr.1,
      data.fr.2,
      data.fr.3
    )
    
    if (nrow(data.comb) != length(unique(data.fr$Modified.sequence))) {
      
      stop(paste("Number of averaged sequences does not match number of unique sequences!"))
    }
    
    data.fr.final <- rbind(data.fr.final, data.comb)
    
  }

  return(data.fr.final)
   
}